# MangaRaw – Mihon Extension

Source: https://freehd24.site/mangaraw/
Language: All (multilingual)
Type: HTML scraper

---

## How to Build & Install

### Prerequisites
- Android Studio (latest stable) OR JDK 17 + Android SDK
- Git

### Steps

1. **Clone the official Mihon extensions template:**
   ```bash
   git clone https://github.com/mihonapp/extensions-template.git
   cd extensions-template
   ```

2. **Copy extension files into the template:**
   ```
   extensions-template/
   └── src/
       └── all/
           └── mangaraw/
               ├── src/
               │   └── MangaRaw.kt         ← copy here
               ├── AndroidManifest.xml     ← copy here
               └── build.gradle.kts        ← copy here
   ```

3. **Add to settings.gradle.kts** (in template root):
   ```kotlin
   include(":extensions:all:mangaraw")
   ```

4. **Build the APK:**
   ```bash
   ./gradlew :extensions:all:mangaraw:assembleDebug
   ```
   Output APK will be at:
   `extensions/all/mangaraw/build/outputs/apk/debug/`

5. **Install on your device:**
   ```bash
   adb install path/to/the.apk
   ```
   Or copy the APK to your phone and open it to sideload.

6. **Enable in Mihon:**
   - Go to Browse → Sources
   - Find "MangaRaw" and enable it

---

## Troubleshooting

- **No results:** The site's HTML selectors may have changed. Open the site in a browser, inspect element, and update the CSS selectors in `MangaRaw.kt`.
- **Images not loading:** The site may use `data-src` lazy-loading. The `pageListParse` function handles both `src` and `data-src`, but additional attributes may need to be added.
- **Chapters not showing:** Check `chapterListSelector()` against the actual site HTML.

---

## Notes

This extension uses HTML scraping. If the site updates its layout, selectors in `MangaRaw.kt` will need to be updated accordingly.
