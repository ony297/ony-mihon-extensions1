package eu.kanade.tachiyomi.extension.all.mangaraw

import eu.kanade.tachiyomi.network.GET
import eu.kanade.tachiyomi.source.model.*
import eu.kanade.tachiyomi.source.online.ParsedHttpSource
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.Request
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

class MangaRaw : ParsedHttpSource() {

    override val name = "MangaRaw"
    override val baseUrl = "https://freehd24.site/mangaraw"
    override val lang = "all"
    override val supportsLatest = true

    // ─── Headers ────────────────────────────────────────────────────────────

    override fun headersBuilder() = super.headersBuilder()
        .add("Referer", "$baseUrl/")

    // ─── Popular ────────────────────────────────────────────────────────────

    override fun popularMangaRequest(page: Int): Request =
        GET("$baseUrl/manga-list/?page=$page&sort=views", headers)

    override fun popularMangaSelector() = "div.manga-item, div.item-manga, div.book-item"

    override fun popularMangaFromElement(element: Element) = SManga.create().apply {
        title = element.selectFirst("h3, .title, .manga-name")?.text() ?: ""
        setUrlWithoutDomain(element.selectFirst("a")?.attr("abs:href") ?: "")
        thumbnail_url = element.selectFirst("img")?.attr("abs:src")
    }

    override fun popularMangaNextPageSelector() = "a.next, li.next > a, .pagination .next"

    // ─── Latest ─────────────────────────────────────────────────────────────

    override fun latestUpdatesRequest(page: Int): Request =
        GET("$baseUrl/manga-list/?page=$page&sort=latest", headers)

    override fun latestUpdatesSelector() = popularMangaSelector()
    override fun latestUpdatesFromElement(element: Element) = popularMangaFromElement(element)
    override fun latestUpdatesNextPageSelector() = popularMangaNextPageSelector()

    // ─── Search ─────────────────────────────────────────────────────────────

    override fun searchMangaRequest(page: Int, query: String, filters: FilterList): Request {
        val url = "$baseUrl/".toHttpUrl().newBuilder()
            .addQueryParameter("s", query)
            .addQueryParameter("page", page.toString())
            .build()
        return GET(url, headers)
    }

    override fun searchMangaSelector() = popularMangaSelector()
    override fun searchMangaFromElement(element: Element) = popularMangaFromElement(element)
    override fun searchMangaNextPageSelector() = popularMangaNextPageSelector()

    // ─── Manga Details ───────────────────────────────────────────────────────

    override fun mangaDetailsParse(document: Document) = SManga.create().apply {
        title = document.selectFirst("h1.entry-title, h1.manga-title, .manga-info h1")?.text() ?: ""
        thumbnail_url = document.selectFirst(".manga-poster img, .thumb img, .cover img")?.attr("abs:src")
        author = document.selectFirst(".author, [itemprop=author]")?.text()
        artist = document.selectFirst(".artist")?.text()
        genre = document.select(".genres a, .tags a, .genre-list a").joinToString { it.text() }
        description = document.selectFirst(".summary, .description, .manga-summary, div.entry-content p")?.text()

        status = when (
            document.selectFirst(".status, .manga-status")?.text()?.lowercase()
        ) {
            "ongoing", "連載中" -> SManga.ONGOING
            "completed", "完結" -> SManga.COMPLETED
            else -> SManga.UNKNOWN
        }
    }

    // ─── Chapter List ────────────────────────────────────────────────────────

    override fun chapterListSelector() = "ul.chapter-list li, div.chapter-list div.item, li.wp-manga-chapter"

    override fun chapterFromElement(element: Element) = SChapter.create().apply {
        val link = element.selectFirst("a")!!
        name = link.text().trim()
        setUrlWithoutDomain(link.attr("abs:href"))
        date_upload = parseDate(element.selectFirst(".date, .chapter-date, span.chapter-release-date")?.text())
    }

    private fun parseDate(text: String?): Long {
        if (text.isNullOrBlank()) return 0L
        return runCatching {
            java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).parse(text.trim())?.time ?: 0L
        }.getOrDefault(0L)
    }

    // ─── Pages ───────────────────────────────────────────────────────────────

    override fun pageListParse(document: Document): List<Page> {
        return document.select(
            "div.reading-content img, " +
            "div.page-break img, " +
            "#readerarea img, " +
            ".chapter-content img"
        ).mapIndexed { index, img ->
            Page(index, "", img.attr("abs:src").ifEmpty { img.attr("abs:data-src") })
        }
    }

    override fun imageUrlParse(document: Document) = ""

    // ─── Filters ─────────────────────────────────────────────────────────────

    override fun getFilterList() = FilterList(
        Filter.Header("Note: Filters may not combine with search text"),
        StatusFilter(),
        SortFilter(),
    )

    private class StatusFilter : Filter.Select<String>(
        "Status",
        arrayOf("All", "Ongoing", "Completed")
    )

    private class SortFilter : Filter.Select<String>(
        "Sort by",
        arrayOf("Latest Update", "Most Views", "New Manga", "A-Z")
    )
}
