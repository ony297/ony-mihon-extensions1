plugins {
    id("com.android.application")
    kotlin("android")
}

android {
    compileSdk = 34
    namespace = "eu.kanade.tachiyomi.extension.all.mangaraw"

    defaultConfig {
        applicationId = "eu.kanade.tachiyomi.extension.all.mangaraw"
        minSdk = 21
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"

        // Mihon / Tachiyomi extension manifest
        manifestPlaceholders += mapOf(
            "appName"       to "MangaRaw",
            "sourceClass"   to ".MangaRaw",
            "sourceFactory" to "",
            "sourceLang"    to "all",
            "sourceVersion" to "1"
        )
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }

    kotlinOptions {
        jvmTarget = "1.8"
    }
}

dependencies {
    // Use the version your Mihon extensions template provides
    compileOnly("eu.kanade.tachiyomi:extensions-lib:1.5")
    implementation("org.jsoup:jsoup:1.17.2")
}
